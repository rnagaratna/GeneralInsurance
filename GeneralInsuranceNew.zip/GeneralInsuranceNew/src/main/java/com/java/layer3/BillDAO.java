package com.java.layer3;

public interface BillDAO {
  double getAmount(int billId);
}