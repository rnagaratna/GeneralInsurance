package com.java.layer3;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;

import com.java.layer2.InsuranceIssued;

public class InsuranceIssuedDAOImpl implements InsuranceIssuedDAO {

	Connection conn;

	public InsuranceIssuedDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "root@123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public InsuranceIssued selectInsuranceIssued(int policyId) {
		 
		InsuranceIssued insuranceIssued = null; 

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsuranceIssued where policyId="+policyId); 
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {
				insuranceIssued = new InsuranceIssued();
				insuranceIssued.setPolicyId(result.getInt(1)); //fill it up column wise
				insuranceIssued.setStartDate(result.getDate(2));
				insuranceIssued.setExpiryDate(result.getDate(3));
				insuranceIssued.setInsuranceTypeId(result.getInt(4));
			}
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		return insuranceIssued;
	}

	@Override
	public List<InsuranceIssued> selectAllInsuranceIssued() {
		List<InsuranceIssued> insuranceIssuedList = new ArrayList<InsuranceIssued>(); 
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsuranceIssued");  
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				InsuranceIssued insuranceIssued = new InsuranceIssued();  
				insuranceIssued.setPolicyId(result.getInt(1));  
				insuranceIssued.setStartDate(result.getDate(2));
				insuranceIssued.setExpiryDate(result.getDate(3));
				insuranceIssued.setInsuranceTypeId(result.getInt(4));
				insuranceIssuedList.add(insuranceIssued);  
			}
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		return insuranceIssuedList;
	}

	@Override
	public void insertInsuranceIssued(InsuranceIssued insuranceIssued) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into InsuranceIssued (startDate,expiryDate,insuranceTypeId) values(?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			//pst.setInt(1, insuranceIssued.getPolicyId());
			
			pst.setDate(1, insuranceIssued.getStartDate());
			pst.setDate(2, insuranceIssued.getExpiryDate());
			
			pst.setInt(3, insuranceIssued.getInsuranceTypeId());

			int rows = pst.executeUpdate();  
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			 
			e1.printStackTrace();
		}
	}

	@Override
	public void updateInsuranceIssued(InsuranceIssued insuranceToModify,int duration)  {
		 long now=System.currentTimeMillis(); 
		 Date startDate = new Date(now);
		 
		 //Date expiryDate = new Date(startDate.getTime()+86400000*30*duration);
		  
		 
		 
		 Calendar calendar=Calendar.getInstance();
		 calendar.setTime(startDate);
		 calendar.add(Calendar.MONTH,duration);
		 Date expiryDate= new Date(calendar.getTimeInMillis());
		 
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE InsuranceIssued set startDate=?, expiryDate=?, insuranceTypeId=? where policyId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setDate(1, startDate);
			pst.setDate(2, expiryDate);
			pst.setInt(3, insuranceToModify.getInsuranceTypeId());
			
			pst.setInt(4, insuranceToModify.getPolicyId());


			int rows = pst.executeUpdate();  
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			 
			e1.printStackTrace();
		}
	}

	@Override
	public void deleteInsuranceIssued(int policyId)
	{
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM InsuranceIssued  where policyId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, policyId);
			
			int rows = pst.executeUpdate();  
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
		 
			e1.printStackTrace();
		}
	}

 
}
