package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.InsuranceType;


public class InsuranceTypeDAOImpl implements InsuranceTypeDAO 
{

	Connection conn;

	public InsuranceTypeDAOImpl() 
	{
			try
			{
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "root@123");
				System.out.println("2. Connected to the DB :" + conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
	}

	@Override
	public InsuranceType selectInsuranceType(int insuranceTypeId) 
	{
		 
		InsuranceType insuranceType = null;  

		try
		{
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsuranceType where insuranceTypeId="+insuranceTypeId);  
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) 
			{
				insuranceType = new InsuranceType();
				insuranceType .setInsuranceTypeId(result.getInt(1)); //fill it up column wise
				insuranceType.setInsuranceName(result.getString(2));
				insuranceType.setInsuranceDescription(result.getString(3));
				insuranceType.setInsuranceCost(result.getDouble(4));
			}
		}
		catch (SQLException e)
		{
			 
			e.printStackTrace();
		}
		return insuranceType;
	}

	@Override
	public List<InsuranceType> selectAllInsuranceType()
	{
		List<InsuranceType> insuranceTypeList = new ArrayList<InsuranceType>();//blank list
		
		try
		{
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsuranceType"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) 
			{
				InsuranceType insuranceType = new InsuranceType(); //make a blank currency object
				insuranceType.setInsuranceTypeId(result.getInt(1)); //fill it up column wise
				insuranceType.setInsuranceName(result.getString(2));
				insuranceType.setInsuranceDescription(result.getString(3));
				insuranceType.setInsuranceCost(result.getDouble(4));
				insuranceTypeList.add(insuranceType); //push this object in the list
			}
		}
		catch (SQLException e) 
		{
			 
			e.printStackTrace();
		}
		return insuranceTypeList;
	}

	@Override
	public void insertInsuranceType(InsuranceType insuranceType)
	{
		 
		try
		{
			PreparedStatement pst = conn.prepareStatement("insert into InsuranceType (insuranceTypeId,insuranceName,insuranceDescription,insuranceCost) values(?,?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			pst.setInt(1, insuranceType.getInsuranceTypeId());
			
			pst.setString(2, insuranceType.getInsuranceName());
			pst.setString(3, insuranceType.getInsuranceDescription());
			
			pst.setDouble(4, insuranceType.getInsuranceCost());

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} 
		catch (SQLException e1)
		{
			 
			e1.printStackTrace();
		}
		
	}

	@Override
	public void updateInsuranceType(InsuranceType insuranceType) {
		 
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE InsuranceType set insuranceName=?, insuranceDescription=?, insuranceCost=? where insuranceTypeId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setString(1, insuranceType.getInsuranceName());
			pst.setString(2, insuranceType.getInsuranceDescription());
			pst.setDouble(3, insuranceType.getInsuranceCost());
			
			pst.setInt(4, insuranceType.getInsuranceTypeId());


			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			 
			e1.printStackTrace();
		}
		
	}

	@Override
	public void deleteInsuranceType(int insuranceTypeId) {
		 
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM InsuranceType  where insuranceTypeId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, insuranceTypeId);
			
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			 
			e1.printStackTrace();
		}
		
	}
}