package com.java.layer4;

import java.util.List;

import com.java.layer2.InsuranceIssued;

public interface InsuranceIssuedService {

	InsuranceIssued viewInsuranceIssuedService(int policyId);
	List<InsuranceIssued> viewAllInsuranceIssuedService();
 

	void addInsuranceIssuedService(InsuranceIssued insuranceIssued);

	void modifyInsuranceIssuedService(InsuranceIssued insuranceIssued,int duration) throws InsuranceStillInProcessException, PolicyIdNotFoundException;
	 
	
	//void removeInsuranceIssuedService(int policyId);

	 

}
