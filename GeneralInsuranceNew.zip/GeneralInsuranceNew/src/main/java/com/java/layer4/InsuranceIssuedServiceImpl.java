package com.java.layer4;

import java.util.List;
import java.sql.Date;
 

import com.java.layer2.InsuranceIssued;
import com.java.layer3.InsuranceIssuedDAO;
import com.java.layer3.InsuranceIssuedDAOImpl;
 


public class InsuranceIssuedServiceImpl implements InsuranceIssuedService{

	InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();
	
	public InsuranceIssuedServiceImpl() {
		System.out.println("InsuranceIssued Service Implementation ctr()..");
	}

	@Override
	public List<InsuranceIssued> viewAllInsuranceIssuedService() {
		List<InsuranceIssued> insuranceList = insuranceDao.selectAllInsuranceIssued();
		return insuranceList;
	}

	@Override
	public void addInsuranceIssuedService(InsuranceIssued insuranceToAdd)
	{
		insuranceDao.insertInsuranceIssued(insuranceToAdd);
		 
		System.out.println("Insurance added");
	}
 
	
	@Override
	public void modifyInsuranceIssuedService(InsuranceIssued insuranceToModify,int duration) throws InsuranceStillInProcessException,PolicyIdNotFoundException
	{
		 long now=System.currentTimeMillis();
		Date d1 = new Date(now);
		 
		 
		// insuranceDao.updateInsuranceIssued(insuranceToModify, 6);
		List<InsuranceIssued> listInsurances = insuranceDao.selectAllInsuranceIssued();
			boolean insuranceFound = false;
			
			for(InsuranceIssued insurance : listInsurances)
			{
				 
				if(insuranceToModify.getPolicyId() == insurance.getPolicyId() && d1.compareTo(insurance.getExpiryDate()) > 0) 
				{
					insuranceFound = true;
					break;
				}
			}
			if(insuranceFound == false) 
				throw new InsuranceStillInProcessException("Couldn't find insurance details!");
			else
			{
				insuranceDao.updateInsuranceIssued(insuranceToModify, 6);
				return;
				
			}
		 
			//System.out.println("Insurance modified");
		 
		
	}

	@Override
	public InsuranceIssued viewInsuranceIssuedService(int policyId) {
		InsuranceIssued insurance = insuranceDao.selectInsuranceIssued(policyId);
		return insurance;
	}
 

	 

}
