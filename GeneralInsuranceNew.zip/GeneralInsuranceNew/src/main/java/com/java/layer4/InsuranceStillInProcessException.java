package com.java.layer4;

public class InsuranceStillInProcessException extends Exception {
	public InsuranceStillInProcessException(String str) {
		super(str);
		
	}
}
