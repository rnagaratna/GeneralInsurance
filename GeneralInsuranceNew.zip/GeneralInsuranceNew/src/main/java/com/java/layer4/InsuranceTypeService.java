package com.java.layer4;

import java.util.List;

import com.java.layer2.InsuranceType;

public interface InsuranceTypeService {

	InsuranceType viewInsuranceTypeService(int insuranceTypeId);
	List<InsuranceType> viewAllInsuranceTypeService();
 

	void addInsuranceTypeService(InsuranceType insuranceType);

	void modifyInsuranceTypeService(InsuranceType insuranceType);
	 
	
	//void removeInsuranceTypeService(int insuranceTypeId);

	 

}
