package com.java.layer4;

import java.util.List;

import com.java.layer2.InsuranceType;
import com.java.layer3.InsuranceTypeDAO;
import com.java.layer3.InsuranceTypeDAOImpl;
 


public class InsuranceTypeServiceImpl implements InsuranceTypeService{

	InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();
	
	public InsuranceTypeServiceImpl() {
		System.out.println("InsuranceType Service Implementation ctr()..");
	}

	@Override
	public List<InsuranceType> viewAllInsuranceTypeService() {
		List<InsuranceType> insuranceList = insuranceDao.selectAllInsuranceType();
		return insuranceList;
	}

	@Override
	public void addInsuranceTypeService(InsuranceType insuranceTypeToAdd)
	{
		insuranceDao.insertInsuranceType(insuranceTypeToAdd);
		 
		System.out.println("InsuranceType added");
	}
 
	
	@Override
	public void modifyInsuranceTypeService(InsuranceType insuranceTypeToModify )
	{
		 insuranceDao.updateInsuranceType(insuranceTypeToModify);
		 System.out.println("InsuranceType modified");
		 
		
	}

	@Override
	public InsuranceType viewInsuranceTypeService(int insuranceTypeId) {
		InsuranceType insurance = insuranceDao.selectInsuranceType(insuranceTypeId);
		return insurance;
	}
 

	 

}
