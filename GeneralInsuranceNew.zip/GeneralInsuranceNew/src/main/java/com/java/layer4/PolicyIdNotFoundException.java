package com.java.layer4;

public class PolicyIdNotFoundException extends Exception {
	public  PolicyIdNotFoundException(String str) {
		super(str);
		
	}
}
