package com.java.layer5;

import java.util.Iterator;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.java.layer2.InsuranceIssued;
import com.java.layer4.InsuranceIssuedService;
import com.java.layer4.InsuranceIssuedServiceImpl;
 
 


@Path("/insurancedb") 
public class InsuranceDBController {	
	InsuranceIssuedService insuranceIssuedService = new InsuranceIssuedServiceImpl();
	
	public InsuranceDBController()
	{
		System.out.println("InsuranceIssued Service called...");
	}

	 
	@POST 
	@Path("/add")
	public String addIt(InsuranceIssued insuranceObj)
	{
			insuranceIssuedService.addInsuranceIssuedService(insuranceObj);
			return "Insurance added successfully";	 
	}
	
	/*
	@PUT
	@Path("/modify")
	public String modifyIt(InsuranceIssued insuranceObj) {
		 
		 
	}
	
*/ 
	 
	@GET
	@Path("/view/{policyid}")
	@Produces(MediaType.APPLICATION_JSON)
	public InsuranceIssued viewIt(@PathParam("policyid") int x) {
		List<InsuranceIssued> insuranceList = insuranceIssuedService.viewAllInsuranceIssuedService();
		InsuranceIssued insurance=null;
		for (InsuranceIssued insuranceIssued : insuranceList) {
			if(insuranceIssued.getPolicyId() == x) {
				insurance = insuranceIssued;
			}
		}
		return insurance;
	}
	
	
	
	@GET
	@Path("/viewAll")
	@Produces(MediaType.APPLICATION_JSON)
	public List<InsuranceIssued> viewAll() {	
		List<InsuranceIssued> insuranceList = insuranceIssuedService.viewAllInsuranceIssuedService();
		return insuranceList;
	}
	
	/*
	@DELETE @Path("/delete/{policyid}")
	public String deleteIt(@PathParam("policyid") int x) {
		boolean found=false;InsuranceIssued insurance=null;
		for (InsuranceIssued insuranceIssued : insuranceList) {
			if(insuranceIssued.getPolicyId() == x) {
				insurance= insuranceIssued;insuranceList.remove(insurance);found=true;break;
			}
		}
		if(found==true) return "Insurance deleted";
		else return "Insurance Not Found :"+x;
	}
	*/

	
}
