package com.java.dao;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.InsuranceIssued;
import com.java.layer2.InsuranceType;
import com.java.layer3.InsuranceIssuedDAO;
import com.java.layer3.InsuranceIssuedDAOImpl;
import com.java.layer3.InsuranceTypeDAO;
import com.java.layer3.InsuranceTypeDAOImpl;


public class DAOImplTest {

	

	@Test
	public void testAllInsuranceIssued()
	{
		System.out.println("started DAO testing...");
		
		InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();
		
	    Assertions.assertTrue(insuranceDao!=null);
		
		List<InsuranceIssued> insuranceIssuedList=insuranceDao.selectAllInsuranceIssued();
	    Assertions.assertTrue(insuranceIssuedList.size() > 0 );
		
		for (InsuranceIssued insuranceIssued : insuranceIssuedList) {
			System.out.println("InsuranceIssued : "+insuranceIssued);
		}
	
	}
	
	@Test
	public void testLoadSingleInsuranceIssued()
	{
		System.out.println("started DAO testing...");
		
		InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();
		
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceIssued insurance=insuranceDao.selectInsuranceIssued(101);
	    Assertions.assertTrue(insurance!=null );
		
		System.out.println("InsuranceIssued : "+insurance);
	
	}
	
	@Test
	public void testAddSingleInsuranceIssued()
	{
		System.out.println("started DAO testing...");
		
		InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceIssued insurance=new InsuranceIssued();
	    Assertions.assertTrue(insurance!=null);
	
		//insurance.setPolicyId(107);
		insurance.setStartDate(Date.valueOf("2023-03-21"));
		insurance.setExpiryDate(Date.valueOf("2024-03-20"));
		insurance.setInsuranceTypeId(2);
		
		System.out.println("InsuranceIssued : "+insurance);
		insuranceDao.insertInsuranceIssued(insurance);
		System.out.println("InsuranceIssued added....");
	}
	
	@Test
	public void testUpdateSingleInsuranceIssued()
	{
		System.out.println("started DAO testing...");
		
		InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceIssued insurance=new InsuranceIssued();
	    Assertions.assertTrue(insurance!=null);
	
		insurance.setPolicyId(116);
		insurance.setStartDate(Date.valueOf("2022-10-25"));
		insurance.setExpiryDate(Date.valueOf("2022-10-24"));
		insurance.setInsuranceTypeId(1);
		
		
		System.out.println("InsuranceIssued : "+insurance);
		insuranceDao.updateInsuranceIssued(insurance,6);
		System.out.println("InsuranceIssued updated....");
	}
	
	@Test
	public void testDeleteSingleInsuranceIssued()
	{
		System.out.println("started DAO testing...");
		
		InsuranceIssuedDAO insuranceDao = new InsuranceIssuedDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		insuranceDao.deleteInsuranceIssued(113);
		System.out.println("InsuranceIssued deleted....");
	}

	

	
	
	
	
	
	
	
	

	@Test
	public void testAllInsuranceType()
	{
		System.out.println("started DAO testing...");
		
		InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();
		
	    Assertions.assertTrue(insuranceDao!=null);
		
		List<InsuranceType> insuranceTypeList=insuranceDao.selectAllInsuranceType();
	    Assertions.assertTrue(insuranceTypeList.size() > 0 );
		
		for (InsuranceType insuranceType : insuranceTypeList) {
			System.out.println("InsuranceType : "+insuranceType);
		}
	
	}
	
	@Test
	public void testLoadSingleInsuranceType()
	{
		System.out.println("started DAO testing...");
		
		InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();
		
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceType insurance=insuranceDao.selectInsuranceType(1);
	    Assertions.assertTrue(insurance!=null );
		
		System.out.println("InsuranceType : "+insurance);
	
	}
	
	@Test
	public void testAddSingleInsuranceType()
	{
		System.out.println("started DAO testing...");
		
		InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceType insurance=new InsuranceType();
	    Assertions.assertTrue(insurance!=null);
	
		insurance.setInsuranceTypeId(3);
		insurance.setInsuranceName("abc");
		insurance.setInsuranceDescription("xyz");
		insurance.setInsuranceCost(1000);
		
		System.out.println("InsuranceType : "+insurance);
		insuranceDao.insertInsuranceType(insurance);
		System.out.println("InsuranceType added....");
	}
	
	@Test
	public void testUpdateSingleInsuranceType()
	{
		System.out.println("started DAO testing...");
		
		InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		InsuranceType insurance=new InsuranceType();
	    Assertions.assertTrue(insurance!=null);
	
		insurance.setInsuranceTypeId(3);
		insurance.setInsuranceName("xyz");
		insurance.setInsuranceDescription("pqr");
		insurance.setInsuranceCost(1000);
		
		System.out.println("InsuranceType : "+insurance);
		insuranceDao.updateInsuranceType(insurance);
		System.out.println("InsuranceType updated....");
	}
	

	@Test
	public void testDeleteSingleInsuranceType()
	{
		System.out.println("started DAO testing...");
		
		InsuranceTypeDAO insuranceDao = new InsuranceTypeDAOImpl();	
	    Assertions.assertTrue(insuranceDao!=null);
		
		insuranceDao.deleteInsuranceType(3);
		System.out.println("InsuranceType deleted....");
	}
	
	
	
}

