package com.java.service;


import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.java.layer2.InsuranceIssued;
import com.java.layer2.InsuranceType;
import com.java.layer4.InsuranceIssuedService;
import com.java.layer4.InsuranceIssuedServiceImpl;
import com.java.layer4.InsuranceStillInProcessException;
import com.java.layer4.InsuranceTypeService;
import com.java.layer4.InsuranceTypeServiceImpl;
import com.java.layer4.PolicyIdNotFoundException;
 
 
public class ServiceImplTest {

	
	@Test
	public void addInsuranceIssuedTest()
	{
		
		InsuranceIssuedService insuranceService = new InsuranceIssuedServiceImpl();
		
		InsuranceIssued insuranceToAdd = new InsuranceIssued();
		
		insuranceToAdd.setStartDate(Date.valueOf("2023-08-21"));
		insuranceToAdd.setExpiryDate(Date.valueOf("2024-08-20"));
		insuranceToAdd.setInsuranceTypeId(1);
		 
		insuranceService.addInsuranceIssuedService(insuranceToAdd);
		
		
	}
	
	
	@Test
	public void modifyInsuranceIssuedTest()
	{
		
		InsuranceIssuedService insuranceService = new InsuranceIssuedServiceImpl();
		InsuranceIssued insuranceToModify = new InsuranceIssued();
		
		insuranceToModify.setPolicyId(117);
		insuranceToModify.setStartDate(Date.valueOf("2000-8-25"));
		insuranceToModify.setExpiryDate(Date.valueOf("2001-8-24"));
		insuranceToModify.setInsuranceTypeId(2);
		 
	 
		try {
			insuranceService.modifyInsuranceIssuedService(insuranceToModify, 6) ;
		} catch (InsuranceStillInProcessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PolicyIdNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void viewAllInsuranceIssuedTest() {
		
		InsuranceIssuedService insuranceService = new InsuranceIssuedServiceImpl();
		List<InsuranceIssued> insuranceList = insuranceService.viewAllInsuranceIssuedService();
		
		System.out.println(insuranceList);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Test
	public void addInsuranceTypeTest()
	{
		
		InsuranceTypeService insuranceService = new InsuranceTypeServiceImpl();
		
		InsuranceType insuranceTypeToAdd = new InsuranceType();
		
		insuranceTypeToAdd.setInsuranceTypeId(3);
		insuranceTypeToAdd.setInsuranceName("abc");
		insuranceTypeToAdd.setInsuranceDescription("gef");
		insuranceTypeToAdd.setInsuranceCost(3000);
		 
		insuranceService.addInsuranceTypeService(insuranceTypeToAdd);
		
	}
	
	@Test
	public void modifyInsuranceTypeTest()
	{
		
		InsuranceTypeService insuranceService = new InsuranceTypeServiceImpl();
		InsuranceType insuranceTypeToModify = new InsuranceType();
		
		insuranceTypeToModify.setInsuranceTypeId(3);
		insuranceTypeToModify.setInsuranceName("xyz");
		insuranceTypeToModify.setInsuranceDescription("pqr");
		insuranceTypeToModify.setInsuranceCost(2000);
		 
	 
		insuranceService.modifyInsuranceTypeService(insuranceTypeToModify);
		
	}
	
	@Test
	public void viewAllInsuranceTypeTest() {
		
		InsuranceTypeService insuranceService = new InsuranceTypeServiceImpl();
		List<InsuranceType> insuranceList = insuranceService.viewAllInsuranceTypeService();
		
		System.out.println(insuranceList);
	}
	 
}

